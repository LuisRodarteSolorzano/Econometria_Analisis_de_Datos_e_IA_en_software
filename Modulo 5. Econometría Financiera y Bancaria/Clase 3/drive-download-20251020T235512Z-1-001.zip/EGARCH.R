# ----------------------------------------
# MODELO EGARCH COMPLETO PARA AAPL
# ----------------------------------------

# 1. Instalar y cargar paquetes
install.packages(c("quantmod", "rugarch", "tseries", "FinTS"))
library(quantmod)
library(rugarch)
library(tseries)
library(FinTS)

# 2. Descargar precios de AAPL
getSymbols("AAPL", from = "2018-01-01", to = "2024-12-31", src = "yahoo")
prices <- Ad(AAPL)  # Precio de cierre ajustado

# 3. Visualizar el precio
plot(prices, main = "Precio Ajustado de AAPL", col = "darkblue", ylab = "Precio (USD)")

# 4. Calcular retornos logarítmicos diarios
returns <- na.omit(dailyReturn(prices, type = "log"))
colnames(returns) <- "AAPL"

# 5. Visualizar retornos
plot(returns, main = "Retornos Logarítmicos Diarios - AAPL", col = "red")

# 6. Verificar estacionariedad - ADF Test
print(adf.test(returns))
plot(returns, main = "Evaluación Visual de Estacionariedad", col = "purple")

# 7. ACF y PACF de retornos y retornos^2
par(mfrow = c(2,2))
acf(returns, main = "ACF de Retornos")
pacf(returns, main = "PACF de Retornos")
acf(returns^2, main = "ACF de Retornos^2")
pacf(returns^2, main = "PACF de Retornos^2")

# 8. Prueba de heterocedasticidad (ARCH)
print(ArchTest(returns, lags = 12))

# 9. Especificar el modelo EGARCH
spec_egarch <- ugarchspec(
  variance.model = list(model = "eGARCH", garchOrder = c(1, 1)),
  mean.model     = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

# 10. Estimar el modelo EGARCH
fit_egarch <- ugarchfit(spec = spec_egarch, data = returns)

# 11. Mostrar resultados clave
print(fit_egarch)
cat("\nLog-verosimilitud:", likelihood(fit_egarch), "\n")
cat("AIC:", infocriteria(fit_egarch)[1], "\n")
cat("BIC:", infocriteria(fit_egarch)[2], "\n")

# 12. Interpretar efecto asimétrico (gamma)
gamma <- coef(fit_egarch)["gamma1"]
cat("Gamma (asimetría):", gamma, "\n")

# 13. Gráficos de volatilidad y media condicional
par(mfrow = c(2,1))
plot(sigma(fit_egarch), main = "Volatilidad Condicional - AAPL (EGARCH)", col = "blue", ylab = "σ_t")
plot(fitted(fit_egarch), main = "Media Condicional - AAPL", col = "darkgreen", ylab = "μ_t")

# 14. Gráficos de diagnóstico
for (i in 1:4) {
  plot(fit_egarch, which = i)
}



# -------------------------------
# COMPARACIÓN GARCH vs TGARCH vs EGARCH
# -------------------------------

# 1. Especificar modelos
spec_garch <- ugarchspec(
  variance.model = list(model = "sGARCH", garchOrder = c(1, 1)),
  mean.model = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

spec_tgarch <- ugarchspec(
  variance.model = list(model = "gjrGARCH", garchOrder = c(1, 1)),
  mean.model = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

spec_egarch <- ugarchspec(
  variance.model = list(model = "eGARCH", garchOrder = c(1, 1)),
  mean.model = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

# 2. Ajustar modelos
fit_garch <- ugarchfit(spec = spec_garch, data = returns)
fit_tgarch <- ugarchfit(spec = spec_tgarch, data = returns)
fit_egarch <- ugarchfit(spec = spec_egarch, data = returns)

# 3. Comparar resultados
model_names <- c("GARCH", "TGARCH", "EGARCH")
loglik <- c(likelihood(fit_garch), likelihood(fit_tgarch), likelihood(fit_egarch))
aic <- c(infocriteria(fit_garch)[1], infocriteria(fit_tgarch)[1], infocriteria(fit_egarch)[1])
bic <- c(infocriteria(fit_garch)[2], infocriteria(fit_tgarch)[2], infocriteria(fit_egarch)[2])
gamma <- c(NA,
           coef(fit_tgarch)["gamma1"],
           coef(fit_egarch)["gamma1"])

# Crear tabla resumen
comparison <- data.frame(
  Modelo = model_names,
  LogLik = loglik,
  AIC = aic,
  BIC = bic,
  Gamma = gamma
)

print(comparison)

par(mfrow=c(1,1))
# Parámetros del modelo EGARCH(1,1)
omega <- -0.3865
alpha <- -0.1082
beta <- 0.9512
gamma <- 0.2079

# Número de periodos para simular
T <- 50

# Inicializar log-volatilidad condicional
log_sigma2_pos <- numeric(T)
log_sigma2_neg <- numeric(T)

# Inicial: usar el valor en estado estacionario como proxy
log_sigma2_pos[1] <- omega / (1 - beta)
log_sigma2_neg[1] <- omega / (1 - beta)

# Simulación: shock positivo vs negativo en t=1, luego sin shocks adicionales
for (t in 2:T) {
  z_pos <- ifelse(t == 2, +0.02, 0)
  z_neg <- ifelse(t == 2, -0.02, 0)
  
  log_sigma2_pos[t] <- omega + beta * log_sigma2_pos[t - 1] +
    alpha * abs(z_pos) + gamma * z_pos
  
  log_sigma2_neg[t] <- omega + beta * log_sigma2_neg[t - 1] +
    alpha * abs(z_neg) + gamma * z_neg
}

# Volatilidad (no en log)
sigma_pos <- exp(log_sigma2_pos / 2)
sigma_neg <- exp(log_sigma2_neg / 2)

# Graficar
plot(1:T, sigma_pos, type = "l", col = "blue", ylim = range(c(sigma_pos, sigma_neg)),
     ylab = expression(sigma[t]), xlab = "Tiempo", lwd = 2,
     main = "Simulación del efecto asimétrico en modelo EGARCH")
lines(1:T, sigma_neg, col = "red", lwd = 2)
legend("topright", legend = c("Shock positivo", "Shock negativo"),
       col = c("blue", "red"), lwd = 2)

