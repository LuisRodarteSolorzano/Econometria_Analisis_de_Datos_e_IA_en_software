# ----------------------------- #
# 1. LIBRERÍAS
# ----------------------------- #
install.packages("rmgarch")
library(quantmod)
library(rugarch)
library(rmgarch)
library(tseries)
library(FinTS)
library(PerformanceAnalytics)

# ----------------------------- #
# 2. DESCARGA DE DATOS
# ----------------------------- #
symbols <- c("AAPL", "MSFT")
getSymbols(symbols, from = "2018-01-01", to = "2024-12-31", src = "yahoo")

prices <- na.omit(merge(Ad(AAPL), Ad(MSFT)))
colnames(prices) <- c("AAPL", "MSFT")

# ----------------------------- #
# 3. GRÁFICOS INICIALES DE PRECIOS
# ----------------------------- #
par(mfrow = c(2, 1))
plot(prices$AAPL, main = "Precio de Cierre Ajustado: AAPL", col = "blue")
plot(prices$MSFT, main = "Precio de Cierre Ajustado: MSFT", col = "green")

# ----------------------------- #
# 4. RETORNOS LOGARÍTMICOS
# ----------------------------- #
returns <- na.omit(merge(
  dailyReturn(prices$AAPL, type = "log"),
  dailyReturn(prices$MSFT, type = "log")
))
colnames(returns) <- c("AAPL", "MSFT")

# Gráficos de retornos
par(mfrow = c(2,1))
plot(returns$AAPL, main = "Retorno logarítmico AAPL", col = "red")
plot(returns$MSFT, main = "Retorno logarítmico MSFT", col = "darkgreen")

# ----------------------------- #
# 5. VERIFICACIÓN DE ESTACIONARIEDAD (ADF TEST)
# ----------------------------- #
adf.test(returns$AAPL)
adf.test(returns$MSFT)

# ----------------------------- #
# 6. GRÁFICOS DE ACF y ACF AL CUADRADO
# ----------------------------- #
par(mfrow = c(2, 2))
acf(returns$AAPL, main = "ACF Retorno AAPL")
acf(returns$AAPL^2, main = "ACF Cuadrado AAPL")
acf(returns$MSFT, main = "ACF Retorno MSFT")
acf(returns$MSFT^2, main = "ACF Cuadrado MSFT")

# ----------------------------- #
# 7. PRUEBA ARCH PARA HETEROCEDASTICIDAD
# ----------------------------- #
ArchTest(returns$AAPL, lags = 12)
ArchTest(returns$MSFT, lags = 12)

# ----------------------------- #
# 8. ESPECIFICACIÓN Y ESTIMACIÓN DEL MODELO DCC-GARCH
# ----------------------------- #
# Univariado GARCH(1,1) para cada serie
uspec <- ugarchspec(
  variance.model = list(model = "sGARCH", garchOrder = c(1, 1)),
  mean.model = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

# Multivariado: DCC(1,1)
spec_dcc <- dccspec(
  uspec = multispec(replicate(2, uspec)), 
  dccOrder = c(1, 1), 
  distribution = "mvnorm"
)

# Ajustar modelo
fit_dcc <- dccfit(spec_dcc, data = returns)

# ----------------------------- #
# 9. GRÁFICOS DE VOLATILIDAD CONDICIONAL
# ----------------------------- #
vols <- sigma(fit_dcc)
par(mfrow = c(2, 1))
plot(vols[,1], main = "Volatilidad Condicional AAPL", col = "red", ylab = "σ_t")
plot(vols[,2], main = "Volatilidad Condicional MSFT", col = "blue", ylab = "σ_t")

# ----------------------------- #
# 10. GRÁFICO DE CORRELACIÓN CONDICIONAL DINÁMICA
# ----------------------------- #
correlations <- rcor(fit_dcc)
plot.ts(correlations[1,2,], main = "Correlación Condicional AAPL-MSFT", col = "purple", ylab = "ρ_t")

# ----------------------------- #
# 11. RESULTADOS DEL MODELO
# ----------------------------- #
# Coeficientes
print(coef(fit_dcc))

# Criterios de información
print(infocriteria(fit_dcc))

# Log-verosimilitud
print(likelihood(fit_dcc))

# Diagnóstico visual completo
for (i in 1:5) {
  plot(fit_dcc, which = i)
}
