# -----------------------------------------------
# MODELO TGARCH (GJR-GARCH) PARA AAPL EN R
# -----------------------------------------------

# Instalar paquetes si no los tienes
install.packages(c("quantmod", "rugarch", "tseries", "FinTS"))
library(quantmod)
library(rugarch)
library(tseries)
library(FinTS)

# 1. Descargar precios históricos de AAPL
getSymbols("AAPL", from = "2018-01-01", to = "2024-12-31", src = "yahoo")
prices <- Ad(AAPL)  # Precio de cierre ajustado

# 2. Gráfico inicial del precio
plot(prices, main = "Precio de Cierre Ajustado - AAPL", col = "darkblue", ylab = "Precio (USD)")

# 3. Calcular retornos logarítmicos diarios
returns <- na.omit(dailyReturn(prices, type = "log"))
colnames(returns) <- "AAPL"

# 4. Gráfico de retornos logarítmicos
plot(returns, main = "Retornos Logarítmicos Diarios - AAPL", col = "darkred", ylab = "Retorno")

# 5. Verificación gráfica de estacionariedad
par(mfrow = c(1,1))
plot(returns, main = "Evaluación Visual de Estacionariedad", col = "purple")

# 6. Prueba ADF (Augmented Dickey-Fuller)
adf_result <- adf.test(returns)
print(adf_result)

# 7. ACF y PACF de retornos y retornos al cuadrado
par(mfrow = c(2,2))
acf(returns, main = "ACF de Retornos")
pacf(returns, main = "PACF de Retornos")
acf(returns^2, main = "ACF de Retornos^2")
pacf(returns^2, main = "PACF de Retornos^2")

# 8. Prueba ARCH (Engle) para heterocedasticidad
arch_result <- ArchTest(returns, lags = 12)
print(arch_result)

# 9. Especificar modelo TGARCH
spec_tgarch <- ugarchspec(
  variance.model = list(model = "gjrGARCH", garchOrder = c(1, 1)),
  mean.model     = list(armaOrder = c(0, 0), include.mean = TRUE),
  distribution.model = "norm"
)

# 10. Ajustar modelo TGARCH
fit_tgarch <- ugarchfit(spec = spec_tgarch, data = returns)

# 11. Mostrar resultados clave
print(fit_tgarch)
cat("\nLog-verosimilitud:", likelihood(fit_tgarch), "\n")
cat("AIC:", infocriteria(fit_tgarch)[1], "\n")
cat("BIC:", infocriteria(fit_tgarch)[2], "\n")
cat("Gamma (efecto asimétrico):", coef(fit_tgarch)["gamma1"], "\n")

# 12. Gráficos del modelo
par(mfrow = c(2,1))
plot(sigma(fit_tgarch), main = "Volatilidad Condicional - AAPL (TGARCH)", col = "blue", ylab = "σ_t")
plot(fitted(fit_tgarch), main = "Media Condicional - AAPL", col = "darkgreen", ylab = "μ_t")

# 13. Gráficos de diagnóstico: residuos, QQ, ACF residuales
for (i in 1:4) {
  plot(fit_tgarch, which = i)
}


# Realizar pronóstico de 30 días
forecast_tgarch <- ugarchforecast(fit_tgarch, n.ahead = 30)

# Extraer la desviación estándar condicional (volatilidad) del forecast
vol_forecast <- sigma(forecast_tgarch)

# Extraer la media condicional del forecast
mu_forecast <- fitted(forecast_tgarch)

# Mostrar resultados
print("Pronóstico de media condicional:")
print(mu_forecast)

print("Pronóstico de volatilidad condicional:")
print(vol_forecast)


# 1. Forecast con 30 días
forecast_tgarch <- ugarchforecast(fit_tgarch, n.ahead = 30)

# 2. Extraer forecast de sigma y media
vol_forecast <- sigma(forecast_tgarch)
mu_forecast  <- fitted(forecast_tgarch)

# 3. Crear vector de fechas hábiles futuras
# Obtener última fecha observada
last_date <- tail(index(returns), 1)

# Generar días calendario hasta cubrir al menos 30 días hábiles
calendar_dates <- seq(from = last_date + 1, by = "days", length.out = 60)

# Filtrar solo días hábiles (lunes a viernes)
biz_dates <- calendar_dates[!(weekdays(calendar_dates) %in% c("Saturday", "Sunday"))][1:30]

# 4. Crear dataframe
vol_df <- data.frame(
  Fecha = biz_dates,
  Volatilidad = as.numeric(vol_forecast)
)

# 5. Graficar forecast
ggplot(vol_df, aes(x = Fecha, y = Volatilidad)) +
  geom_line(color = "blue", linewidth = 1) +  # Usamos linewidth en vez de size
  labs(
    title = "Forecast de Volatilidad Condicional - Modelo TGARCH",
    x = "Fecha",
    y = expression(sigma[t])
  ) +
  theme_minimal()

#Forecast de la media condicional

mu_df <- data.frame(Fecha = biz_dates, Media = as.numeric(mu_forecast))
ggplot(mu_df, aes(x = Fecha, y = Media)) +
  geom_line(color = "darkgreen", linewidth = 1) +
  labs(title = "Forecast de la Media Condicional - Modelo TGARCH",
       x = "Fecha", y = expression(mu[t])) +
  theme_minimal()

# 1. Calcular VaR al 95% (cuantil normal)
z_95 <- qnorm(0.05)  # Para 95% de confianza
VaR_95 <- mu_forecast + z_95 * vol_forecast

# 2. Crear dataframe
var_df <- data.frame(
  Fecha = biz_dates,
  VaR_95 = as.numeric(VaR_95)
)

# 3. Graficar el VaR
library(ggplot2)
ggplot(var_df, aes(x = Fecha, y = VaR_95)) +
  geom_line(color = "red", linewidth = 1) +
  labs(
    title = "Forecast del VaR Diario al 95% - Modelo TGARCH",
    x = "Fecha",
    y = "VaR (retorno mínimo esperado)"
  ) +
  theme_minimal()
  
