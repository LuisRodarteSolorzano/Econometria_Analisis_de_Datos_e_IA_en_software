# Instala (si es necesario) y carga las librerías requeridas
# install.packages("shiny")
# install.packages("quantmod")
# install.packages("PerformanceAnalytics")
# install.packages("mvtnorm")
# install.packages("TTR")
# install.packages("DT")

library(shiny)
library(quantmod)
library(PerformanceAnalytics)
library(mvtnorm)  # Para simulación Monte Carlo
library(TTR)
library(DT)

# UI de la aplicación
ui <- fluidPage(
  titlePanel("Análisis Financiero y Gestión de Riesgo"),
  sidebarLayout(
    sidebarPanel(
      h4("Opciones de Descarga y Datos"),
      # Permite seleccionar o agregar un ticker para gráficos individuales
      selectizeInput("ticker", "Selecciona o Agrega ticker (Gráficos individuales):", 
                     choices = c("AAPL"), selected = "AAPL", multiple = FALSE,
                     options = list(create = TRUE)),
      # Permite seleccionar o agregar tickers para el portafolio
      selectizeInput("portfolioTickers", "Tickers del Portafolio:", 
                     choices = c("AAPL", "MSFT", "GOOG"), 
                     selected = c("AAPL", "MSFT", "GOOG"), multiple = TRUE,
                     options = list(create = TRUE)),
      dateRangeInput("dates", "Rango de Fechas:", 
                     start = "2020-01-01", end = Sys.Date()),
      actionButton("update", "Actualizar Datos"),
      br(), br(),
      downloadButton("downloadData", "Descargar Data Histórica")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Gráficos Individuales",
                 h4("1. Velas con Indicadores (Volumen, Bandas de Bollinger, SMA 50 y 200)"),
                 plotOutput("chart1", height = "400px"),
                 h4("2. Precio Ajustado - Gráfico de Línea"),
                 plotOutput("chart2", height = "300px"),
                 h4("3. Velas con RSI, MACD y SMA de 20 días"),
                 plotOutput("chart3", height = "400px"),
                 h4("4. Resumen de Desempeño"),
                 plotOutput("performanceAAPL", height = "400px"),
                 h4("5. Volatilidad (ATR y Volumen)"),
                 plotOutput("chartVolatilityAAPL", height = "400px"),
                 h4("6. VaR Individual (Histórico, Paramétrico y Monte Carlo)"),
                 verbatimTextOutput("riskMetricsIndividual")
        ),
        tabPanel("Portafolio",
                 h4("Resumen de Rendimiento del Portafolio"),
                 plotOutput("performancePortfolio", height = "400px"),
                 h4("Cálculo de VaR y Ratio de Sharpe del Portafolio"),
                 verbatimTextOutput("riskMetrics")
        ),
        tabPanel("Descargar Data",
                 h4("Data Histórica (Precios Ajustados)"),
                 DT::dataTableOutput("dataTable")
        )
      )
    )
  )
)

# Server de la aplicación
server <- function(input, output, session) {
  
  # Valores reactivos para almacenar los datos descargados
  dataAAPL <- reactiveVal(NULL)
  dataPortfolio <- reactiveVal(NULL)
  returnsData <- reactiveVal(NULL)
  returnsPortfolio <- reactiveVal(NULL)
  
  # Actualizar datos al presionar el botón
  observeEvent(input$update, {
    # Descargar datos para el ticker individual con manejo de errores
    ticker <- input$ticker
    data <- tryCatch({
      getSymbols(ticker, from = input$dates[1], to = input$dates[2], auto.assign = FALSE)
    }, error = function(e) {
      showNotification(paste("No se pudo descargar:", ticker), type = "error")
      return(NULL)
    })
    if (!is.null(data)) {
      dataAAPL(data)
    } else {
      dataAAPL(NULL)
    }
    
    # Descargar datos para el portafolio (permite agregar nuevos tickers)
    tickers <- input$portfolioTickers
    portfolioList <- lapply(tickers, function(tkr) {
      out <- try(getSymbols(tkr, from = input$dates[1], to = input$dates[2], auto.assign = FALSE), silent = TRUE)
      if (inherits(out, "try-error")) {
        showNotification(paste("No se pudo descargar:", tkr), type = "error")
        return(NULL)
      } else {
        return(Ad(out))
      }
    })
    portfolioList <- portfolioList[!sapply(portfolioList, is.null)]
    if(length(portfolioList) == 0){
      showNotification("No se pudieron descargar datos para los tickers ingresados.", type = "error")
      return(NULL)
    }
    portfolioData <- do.call(merge, portfolioList)
    portfolioData <- na.omit(portfolioData)
    dataPortfolio(portfolioData)
    
    # Calcular retornos logarítmicos (portafolio)
    ret <- na.omit(Return.calculate(portfolioData, method = "log"))
    returnsData(ret)
    # Portafolio equiponderado
    pesos <- rep(1/ncol(ret), ncol(ret))
    ret_portf <- Return.portfolio(R = ret, weights = pesos)
    returnsPortfolio(ret_portf)
  })
  
  # Handler para descargar la data histórica del portafolio (precios ajustados)
  output$downloadData <- downloadHandler(
    filename = function() {
      paste("data_portafolio_", Sys.Date(), ".csv", sep = "")
    },
    content = function(file) {
      if (!is.null(dataPortfolio())) {
        write.zoo(dataPortfolio(), file = file, sep = ",")
      }
    }
  )
  
  # Gráficos individuales para el ticker seleccionado
  
  output$chart1 <- renderPlot({
    req(dataAAPL())
    chartSeries(dataAAPL(),
                type = "candlesticks", 
                theme = chartTheme("white"),
                TA = c(addVo(), addBBands(), addSMA(n = 50), addSMA(n = 200)),
                name = paste(input$ticker, ": Velas con Indicadores"))
  })
  
  output$chart2 <- renderPlot({
    req(dataAAPL())
    chartSeries(Ad(dataAAPL()),
                type = "line", 
                theme = chartTheme("white"),
                name = paste(input$ticker, ": Precio Ajustado - Gráfico de Línea"))
  })
  
  output$chart3 <- renderPlot({
    req(dataAAPL())
    chartSeries(dataAAPL(),
                type = "candlesticks", 
                theme = chartTheme("white"),
                TA = c(addRSI(n = 14), addMACD(), addSMA(n = 20)),
                name = paste(input$ticker, ": Velas con RSI, MACD y SMA de 20 días"))
  })
  
  output$performanceAAPL <- renderPlot({
    req(dataAAPL())
    ret <- dailyReturn(Ad(dataAAPL()), type = "log")
    charts.PerformanceSummary(ret, main = paste(input$ticker, " - Resumen de Desempeño"))
  })
  
  output$chartVolatilityAAPL <- renderPlot({
    req(dataAAPL())
    chartSeries(dataAAPL(),
                type = "candlesticks", 
                theme = chartTheme("white"),
                TA = c(addVo(), addSMA(n = 20), addATR(n = 14)),
                name = paste(input$ticker, ": Volatilidad con ATR y Volumen"))
  })
  
  # Calcular y mostrar el VaR individual (para el ticker seleccionado) usando 3 métodos
  output$riskMetricsIndividual <- renderPrint({
    req(dataAAPL())
    ret_ind <- dailyReturn(Ad(dataAAPL()), type = "log")
    VaR_hist_ind <- VaR(ret_ind, p = 0.95, method = "historical")
    VaR_param_ind <- VaR(ret_ind, p = 0.95, method = "gaussian")
    set.seed(123)
    num_sim <- 10000
    # Simular usando distribución normal unidimensional
    simulated_ind_returns <- rnorm(num_sim, mean = mean(ret_ind, na.rm = TRUE), sd = sd(ret_ind, na.rm = TRUE))
    VaR_mc_ind <- -quantile(simulated_ind_returns, probs = 0.05)
    
    cat("=== VaR Individual para", input$ticker, "===\n")
    cat("Histórico (95%):\n")
    print(VaR_hist_ind)
    cat("\nParamétrico (Varianza-Covarianza) (95%):\n")
    print(VaR_param_ind)
    cat("\nMonte Carlo (95%):\n")
    print(VaR_mc_ind)
  })
  
  # Gráficos y cálculos para el Portafolio
  
  output$performancePortfolio <- renderPlot({
    req(returnsData())
    charts.PerformanceSummary(returnsData(), main = "Resumen de Rendimiento de Portafolio")
  })
  
  output$riskMetrics <- renderPrint({
    req(returnsData(), returnsPortfolio())
    
    # ------------------------------
    # Cálculo del VaR para el portafolio
    
    # VaR del portafolio (Histórico)
    VaR_portfolio_hist <- VaR(returnsPortfolio(), p = 0.95, method = "historical")
    
    # VaR del portafolio (Varianza-Covarianza)
    VaR_portfolio_varcov <- VaR(returnsPortfolio(), p = 0.95, method = "gaussian")
    
    # VaR del portafolio (Monte Carlo)
    set.seed(123)
    num_sim <- 10000
    mu <- colMeans(returnsData())
    sigma <- cov(returnsData())
    simulated_returns <- rmvnorm(num_sim, mean = mu, sigma = sigma)
    pesos <- rep(1/ncol(returnsData()), ncol(returnsData()))
    simulated_portfolio_returns <- simulated_returns %*% pesos
    VaR_portfolio_mc <- -quantile(simulated_portfolio_returns, probs = 0.05)
    
    # ------------------------------
    # Cálculo del Ratio de Sharpe
    
    # Ratio de Sharpe del portafolio (anualizado)
    Sharpe_ratio_portfolio <- SharpeRatio.annualized(returnsPortfolio(), Rf = 0)
    # Ratio de Sharpe individual (anualizado)
    Sharpe_ratio_individual <- apply(returnsData(), 2, function(x) SharpeRatio.annualized(x, Rf = 0))
    
    # ------------------------------
    # Imprimir los resultados para el portafolio
    cat("=== VaR del Portafolio ===\n")
    cat("Histórico (95%):\n")
    print(VaR_portfolio_hist)
    cat("\nVarianza-Covarianza (95%):\n")
    print(VaR_portfolio_varcov)
    cat("\nMonte Carlo (95%):\n")
    print(VaR_portfolio_mc)
    
    cat("\n=== Ratio de Sharpe ===\n")
    cat("Individual (anualizado):\n")
    print(Sharpe_ratio_individual)
    cat("\nPortafolio (anualizado):\n")
    print(Sharpe_ratio_portfolio)
  })
  
  # Mostrar la data histórica del portafolio en una tabla
  output$dataTable <- DT::renderDataTable({
    req(dataPortfolio())
    DT::datatable(as.data.frame(dataPortfolio()), options = list(pageLength = 10))
  })
}

# Ejecutar la aplicación Shiny
shinyApp(ui = ui, server = server)
