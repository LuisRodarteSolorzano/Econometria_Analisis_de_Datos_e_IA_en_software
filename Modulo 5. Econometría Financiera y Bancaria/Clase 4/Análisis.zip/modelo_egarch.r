# MODELO EGARCH COMPLETO PARA AAPL (MEJORADO)
# ---------------------------------------------------

# 1. Instalar y cargar paquetes
install.packages(c("quantmod", "rugarch", "tseries", "FinTS", "forecast", "PerformanceAnalytics"))
library(quantmod)
library(rugarch)
library(tseries)
library(FinTS)
library(forecast)
library(PerformanceAnalytics)

# 2. Descargar precios de AAPL
data <- getSymbols("AAPL", from = "2018-01-01", to = "2024-12-31", src = "yahoo", auto.assign = FALSE)
prices <- Ad(data)

# 3. Calcular retornos logarítmicos diarios
returns <- na.omit(dailyReturn(prices, type = "log"))
colnames(returns) <- "AAPL"

# 4. Estacionariedad - ADF
print(adf.test(returns))

# 5. ACF y PACF de retornos y retornos^2
par(mfrow = c(2,2))
acf(returns, main = "ACF de Retornos")
pacf(returns, main = "PACF de Retornos")
acf(returns^2, main = "ACF de Retornos^2")
pacf(returns^2, main = "PACF de Retornos^2")

# 6. Prueba de heterocedasticidad
print(ArchTest(returns, lags = 12))

# 7. Estimar modelo ARMA óptimo en la media
best_arima <- auto.arima(returns)
arma_order <- arimaorder(best_arima)[1:2]  # c(p, q)

# 8. Especificar modelo EGARCH con t-Student
spec_egarch <- ugarchspec(
  variance.model = list(model = "eGARCH", garchOrder = c(1,1)),
  mean.model = list(armaOrder = arma_order, include.mean = TRUE),
  distribution.model = "std"  # t-Student
)

# 9. Ajustar modelo EGARCH
fit_egarch <- ugarchfit(spec = spec_egarch, data = returns)
print(fit_egarch)

# 10. Diagnóstico de residuos
resid_std <- residuals(fit_egarch, standardize = TRUE)
cat("\nLjung-Box test en residuos estandarizados:\n")
print(Box.test(resid_std, lag = 20, type = "Ljung-Box"))
cat("\nARCH test en residuos estandarizados:\n")
print(ArchTest(resid_std))

# 11. Forecast de volatilidad
forecast_egarch <- ugarchforecast(fit_egarch, n.ahead = 10)
plot(forecast_egarch, which = 1)  # Volatilidad esperada

# 12. Dividir muestra: entrenamiento vs prueba
train <- returns["2018/2022"]
test <- returns["2023/2024"]
fit_train <- ugarchfit(spec = spec_egarch, data = train)
forecast_test <- ugarchforecast(fit_train, n.ahead = length(test))

# 13. Backtesting de VaR
VaR_1p <- quantile(returns, probs = 0.01)
chart.VaRSensitivity(returns, p = 0.01)

# 14. Interpretación de parámetros
params <- coef(fit_egarch)
cat("\nParámetros del modelo:\n")
print(params)
cat("Gamma (asimetría):", params["gamma1"], "\n")

# 15. Gráficos de volatilidad y media condicional
par(mfrow = c(2,1))
plot(sigma(fit_egarch), main = "Volatilidad Condicional - EGARCH", col = "blue")
plot(fitted(fit_egarch), main = "Media Condicional", col = "green")

# 16. Gráficos de diagnóstico
par(mfrow = c(2,2))
plot(fit_egarch, which = 1)
plot(fit_egarch, which = 2)
plot(fit_egarch, which = 3)
plot(fit_egarch, which = 4)

# 17. Simulación efecto asimétrico
omega <- params["omega"]
alpha <- params["alpha1"]
beta <- params["beta1"]
gamma <- params["gamma1"]
T <- 50
log_sigma2_pos <- numeric(T)
log_sigma2_neg <- numeric(T)
log_sigma2_pos[1] <- omega / (1 - beta)
log_sigma2_neg[1] <- omega / (1 - beta)

for (t in 2:T) {
  z_pos <- ifelse(t == 2, +0.02, 0)
  z_neg <- ifelse(t == 2, -0.02, 0)
  log_sigma2_pos[t] <- omega + beta * log_sigma2_pos[t-1] + alpha * abs(z_pos) + gamma * z_pos
  log_sigma2_neg[t] <- omega + beta * log_sigma2_neg[t-1] + alpha * abs(z_neg) + gamma * z_neg
}

sigma_pos <- exp(log_sigma2_pos / 2)
sigma_neg <- exp(log_sigma2_neg / 2)

plot(1:T, sigma_pos, type = "l", col = "blue", ylim = range(c(sigma_pos, sigma_neg)),
     ylab = expression(sigma[t]), xlab = "Tiempo", lwd = 2,
     main = "Simulación del efecto asimétrico - EGARCH")
lines(1:T, sigma_neg, col = "red", lwd = 2)
legend("topright", legend = c("Shock positivo", "Shock negativo"),
       col = c("blue", "red"), lwd = 2)
