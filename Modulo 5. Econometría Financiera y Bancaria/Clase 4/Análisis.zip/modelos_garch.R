# Volatility Models App - Shiny (Versión con Resultados Completos)

library(shiny)
library(quantmod)
library(rugarch)
library(rmgarch)
library(tseries)

ui <- fluidPage(
  titlePanel("Volatility Models App - ARCH/GARCH/TGARCH/MGARCH"),
  sidebarLayout(
    sidebarPanel(
      textInput("symbols", "Ingrese símbolos (separados por coma):", value = "AAPL,MSFT,TSLA,GOOGL"),
      actionButton("loadData", "Cargar Datos"),
      uiOutput("selectActivo"),
      selectInput("modelo", "Seleccione Modelo:", 
                  choices = c("ARCH", "GARCH", "IGARCH", "TGARCH", "MGARCH")),
      numericInput("p", "Orden p:", value = 1, min = 1, max = 5),
      numericInput("q", "Orden q:", value = 1, min = 0, max = 5),
      actionButton("run", "Ejecutar Modelo")
    ),
    mainPanel(
      plotOutput("volPlot"),
      tableOutput("resultsTable"),
      tableOutput("coefTable"),
      verbatimTextOutput("modeloResumen"),
      plotOutput("diagnosticPlot")
    )
  )
)

server <- function(input, output, session) {
  
  datos_reactivos <- reactiveVal()
  
  observeEvent(input$loadData, {
    symbols <- unlist(strsplit(input$symbols, ","))
    getSymbols(symbols, from = "2018-01-01", to = "2024-12-31", src = "yahoo", auto.assign = TRUE)
    returns_list <- lapply(symbols, function(sym) dailyReturn(Ad(get(sym)), type = "log"))
    returns_data <- na.omit(do.call(merge, returns_list))
    colnames(returns_data) <- symbols
    datos_reactivos(returns_data)
    output$selectActivo <- renderUI({
      if (input$modelo == "MGARCH") {
        selectInput("activo", "Seleccione Activos (mínimo 2):", choices = symbols, multiple = TRUE)
      } else {
        selectInput("activo", "Seleccione Activo:", choices = symbols)
      }
    })
  })
  
  modelo_fit <- eventReactive(input$run, {
    returns_data <- datos_reactivos()
    req(returns_data)
    
    if (input$modelo == "MGARCH") {
      validate(need(length(input$activo) >= 2, "Seleccione al menos 2 activos para MGARCH"))
      data_select <- returns_data[, input$activo]
      uspec <- ugarchspec(
        variance.model = list(model = "sGARCH", garchOrder = c(1,1)),
        mean.model = list(armaOrder = c(0,0), include.mean = TRUE),
        distribution.model = "norm"
      )
      spec <- dccspec(uspec = multispec(replicate(ncol(data_select), uspec)), dccOrder = c(1,1), distribution = "mvnorm")
      return(dccfit(spec, data = data_select))
    } else {
      data_select <- returns_data[, input$activo]
      model_type <- switch(input$modelo,
                           "ARCH" = list(model = "sGARCH", order = c(input$p, 0)),
                           "GARCH" = list(model = "sGARCH", order = c(input$p, input$q)),
                           "IGARCH" = list(model = "iGARCH", order = c(input$p, input$q)),
                           "TGARCH" = list(model = "gjrGARCH", order = c(input$p, input$q)))
      
      spec <- ugarchspec(
        variance.model = list(model = model_type$model, garchOrder = model_type$order),
        mean.model = list(armaOrder = c(0,0), include.mean = TRUE),
        distribution.model = "norm"
      )
      return(ugarchfit(spec, data = data_select))
    }
  })
  
  output$volPlot <- renderPlot({
    fit <- modelo_fit()
    if (input$modelo == "MGARCH") {
      correlations <- rcor(fit)
      plot.ts(correlations[1,2,], main = "Correlación Condicional Dinámica", col = "purple")
    } else {
      plot(sigma(fit), main = paste("Volatilidad Condicional -", input$modelo), col = "blue")
    }
  })
  
  output$resultsTable <- renderTable({
    fit <- modelo_fit()
    if (input$modelo == "MGARCH") {
      data.frame(LogLik = likelihood(fit))
    } else {
      data.frame(
        LogLik = likelihood(fit),
        AIC = infocriteria(fit)[1],
        BIC = infocriteria(fit)[2],
        Gamma = ifelse("gamma1" %in% names(coef(fit)), coef(fit)["gamma1"], NA)
      )
    }
  }, rownames = TRUE)
  
  output$coefTable <- renderTable({
    fit <- modelo_fit()
    if (input$modelo != "MGARCH") {
      as.data.frame(t(coef(fit)))
    }
  }, rownames = TRUE)
  
  output$modeloResumen <- renderPrint({
    fit <- modelo_fit()
    if (input$modelo == "MGARCH") {
      show(fit)
    } else {
      show(fit)
    }
  })
  
  output$diagnosticPlot <- renderPlot({
    fit <- modelo_fit()
    if (input$modelo != "MGARCH") {
      plot(fit, which = 1)
    }
  })
}

shinyApp(ui = ui, server = server)


